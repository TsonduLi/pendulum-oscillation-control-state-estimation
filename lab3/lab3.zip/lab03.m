% PROPORTIONAL 
syms alpha
C=0.02;
P=tf([2550],[0.36 1 0]);
figure(1);margin(C*P);

%%
%%q2

C_lag=tf([10 11.7],[10 0]);
alpha_num=double(solve(asind((alpha-1)/(alpha+1))==-7.5833+45));
C_lead=tf([sqrt(alpha_num) 11.7],[1  sqrt(alpha_num)*11.7] );
C1=0.02*C_lag*C_lead;
figure(2);step(C1*P/(1+C1*P));
figure(3);step(P/(1+C1*P));
figure(4);margin(C1*P);
CLTF=feedback(C1*P,1);
info_servo1=stepinfo(CLTF)

%%

wc=20;
k=1/bode(P,wc);
C2=k;
margin(C2*P);

%%
%%q3

C_lag=tf([10 20],[10 0]);
alpha_num=double(solve(asind((alpha-1)/(alpha+1))==-7.5833+45+5.4));
C_lead=tf([sqrt(alpha_num) 20],[1  sqrt(alpha_num)*20] );
C2=k*C_lag*C_lead;
figure(2);step(C2*P/(1+C2*P));
figure(3);step(P/(1+C2*P));
figure(4);margin(C2*P);
CLTF=feedback(C2*P,1);
info_servo1=stepinfo(CLTF)

%%
%%4
figure;plot(out.simout1.Time,out.simout1.Data);grid on
figure;plot(out.simout2.Time,out.simout2.Data);grid on

